# Analysis of Top Instagram Influencers by Andrew An Thai Nguyen (id: 47357525)

## Overview:
You have been provided with a comprehensive dataset named 'Top Instagram Influencer.csv' that contains valuable information about the top Instagram influencers. This dataset includes various attributes related to influencer rankings, influence scores, and engagement metrics. In this README, we will provide an overview of the dataset and outline the key questions and analyses you can perform.

## Getting Started: 

### 1. Data Exploration and Cleaning
- Explore the dataset to understand its structure and characteristics.
- Identify and handle any missing values.
- Remove abnormal instances or outliers that may negatively affect the analysis.

### 2. Feature Encoding
- Convert categorical object features into numerical features using an appropriate encoding method. This step is crucial as machine learning models require numerical inputs.

### 3. Correlation Analysis
- Study the correlation between different features and the target variable  to identify which features may be most informative for the classification task.

### 4. Linear Regression Model
- Split the dataset into training and testing sets.
- Train a logistic regression model to predict 'influence_score' based on the encoded features.
- Evaluate the accuracy of the linear regression model.

### 5. K-Nearest Neighbors (KNN) Model
- Split the dataset into training and testing sets.
- Train a KNN model to predict 'rating' based on the encoded features. Choose an appropriate value for K.
- Evaluate the accuracy of the KNN model.

### 6. Hyperparameter Tuning
- Tune the hyperparameter K in the KNN model to observe its impact on prediction performance.
- Compare the performance of different K values and discuss the results.

### 7. Visualisation 
- Show the differences of accuracies with the different K values.

## Libraries Used: 
- Pandas
- Numpy
- sklearn
- matplotlib.pyplot
- seaborn

## Contributions
This project is maintained by Andrew An Thai Nguyen
